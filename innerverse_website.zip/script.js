const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const STORAGE_KEY = 'innerverse-v1';
const AFFIRMATIONS = [
  'I can be a work in progress and still be wonderful.',
  'I am allowed to take up space, even on quiet days.',
  'My feelings are visitors; I can listen without becoming them.',
  'I do not need to bloom on someone else’s timeline.',
  'Rest is a constellation in my progress, too.',
  'I can ask for help and still be strong.',
  'One small, kind choice is enough for this moment.',
  'There is more to me than what I achieve.'
];
const PROMPTS = [
  'What is one thing you wish someone understood about your day?',
  'When did you feel most like yourself this week?',
  'What is one thing you can let be “good enough” today?',
  'What helped you feel even 1% calmer recently?',
  'If your mood were a sky, what would it need right now?'
];
const MOOD_LABELS = {
  Radiant:{emoji:'☀',description:'A little light is shining through. Let yourself enjoy it.'},
  Floating:{emoji:'☁',description:'Steady or okay is a place to be, too. You don’t need to force a feeling.'},
  Cloudy:{emoji:'☾',description:'Uncertainty is welcome here. You can take things one small step at a time.'},
  Stormy:{emoji:'ϟ',description:'That sounds like a lot to carry. Consider reaching out to someone safe for support.'},
  Restless:{emoji:'✳',description:'There’s energy moving through you. A small creative or grounding activity may help.'}
};
const dayKey = (d) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const keyOffset = (offset) => { const d=new Date(); d.setDate(d.getDate()+offset); return dayKey(d); };
const dayLetter = (key) => ['S','M','T','W','T','F','S'][new Date(key+'T12:00:00').getDay()];
function load(){try{return JSON.parse(localStorage.getItem(STORAGE_KEY))||{days:{},journal:'',affirmation:0};}catch{return {days:{},journal:'',affirmation:0};}}
let state=load();
function save(){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(state));}catch{}}
function day(key){return state.days[key]||{mood:'',emoji:''};}
function today(){if(!state.days[keyOffset(0)])state.days[keyOffset(0)]={mood:'',emoji:''};return state.days[keyOffset(0)];}
let chosen=day(keyOffset(0)).mood||'';
$('#today-label').textContent=new Date().toLocaleDateString(undefined,{weekday:'long',month:'long',day:'numeric'}).toUpperCase()+'  ·  YOUR COSMIC CHECK-IN';

function renderMood(){
  $$('.mood-card').forEach(b=>b.classList.toggle('selected',b.dataset.mood===chosen));
  const status=$('#selected-mood');
  status.textContent=chosen ? `${MOOD_LABELS[chosen].emoji} ${chosen}: ${MOOD_LABELS[chosen].description}` : 'Choose the little sky that feels closest to yours.';
}
function renderHistory(){
  const keys=Array.from({length:7},(_,i)=>keyOffset(i-6));
  $('#mood-history').innerHTML=keys.map(k=>{
    const mood=day(k).mood;
    return `<div class="history-day"><span class="history-star ${mood?'filled':''}" title="${mood||'No check-in'}">${mood?MOOD_LABELS[mood].emoji:'·'}</span><small>${dayLetter(k)}</small></div>`;
  }).join('');
  const moods=keys.map(k=>day(k).mood).filter(Boolean);
  $('#mood-summary').textContent=moods.length?`You checked in on ${moods.length} of 7 days. Every star represents a moment you made time for yourself.`:'Your constellation is waiting for its first star.';
  const difficult=moods.filter(m=>m==='Stormy'||m==='Cloudy').length;
  let reflection='You don’t need to have every answer. Begin by noticing how you feel, one day at a time.';
  if(moods.length>=3 && difficult>=Math.ceil(moods.length/2)) reflection='Your check-ins include some cloudy or stormy moments. You deserve support, not pressure. Consider sharing how you’ve been feeling with someone you trust.';
  else if(moods.length>=3) reflection=`You made space for yourself on ${moods.length} days. What helped on a day that felt a little lighter? Keep noticing, without judging.`;
  $('#weekly-reflection').textContent=reflection;
}
$$('.mood-card').forEach(b=>b.addEventListener('click',()=>{chosen=b.dataset.mood;renderMood();}));
$('#save-mood').addEventListener('click',()=>{
  if(!chosen){$('#selected-mood').textContent='Choose a mood first, or come back whenever you feel ready.';return;}
  today().mood=chosen;today().emoji=MOOD_LABELS[chosen].emoji;today().savedAt=new Date().toISOString();save();renderMood();renderHistory();
  $('#save-mood').innerHTML='Added to your galaxy ✓';
  setTimeout(()=>$('#save-mood').innerHTML='Add this feeling to my galaxy <span>↗</span>',1800);
});
$('#journal-entry').value=state.journal||'';
function updateCount(){$('#word-count').textContent=`${$('#journal-entry').value.length} / 1200 characters`;}
$('#journal-entry').addEventListener('input',updateCount);
$('#save-journal').addEventListener('click',()=>{
  state.journal=$('#journal-entry').value;state.journalSavedAt=new Date().toISOString();save();
  $('#journal-feedback').textContent='Capsule sealed in this browser. Take a breath—you showed up for yourself.';
  $('#save-journal').innerHTML='Capsule sealed ✓';
  setTimeout(()=>$('#save-journal').innerHTML='Seal my capsule <span>✦</span>',1800);
});
$('#next-affirmation').addEventListener('click',()=>{
  state.affirmation=(Number(state.affirmation||0)+1)%AFFIRMATIONS.length;
  $('#affirmation').textContent=AFFIRMATIONS[state.affirmation];save();
});
$('#reflection-prompt').addEventListener('click',()=>{
  const prompt=PROMPTS[Math.floor(Math.random()*PROMPTS.length)];
  $('#weekly-reflection').textContent=prompt;
});
$('#affirmation').textContent=AFFIRMATIONS[(Number(state.affirmation)||0)%AFFIRMATIONS.length];
updateCount();renderMood();renderHistory();
